import React, { useRef, useEffect, useMemo, useState } from "react";
import { useGLTF } from "@react-three/drei";
import { clone } from "three/examples/jsm/utils/SkeletonUtils.js";
import * as THREE from "three";

export function Woman({ mapData, position = [0, 0, 0] }) {
  const group = useRef();
  const { scene, animations } = useGLTF("/models/woman.glb");
  const cloned = useMemo(() => clone(scene), [scene]);
  const mixer = useMemo(() => new THREE.AnimationMixer(cloned), [cloned]);
  const clock = useMemo(() => new THREE.Clock(), []);

  const [path, setPath] = useState([]);
  const [idx, setIdx] = useState(0);
  const speed = 0.00015;

  // --- Dijkstra pour trouver un chemin ---
  const findPath = (start, end) => {
    const { nodes, links } = mapData;
    const dist = {}, prev = {}, Q = new Set(nodes.map(n => n.id));
    nodes.forEach(n => dist[n.id] = Infinity);
    dist[start] = 0;
    while (Q.size > 0) {
      let u = [...Q].reduce((a, b) => dist[a] < dist[b] ? a : b);
      Q.delete(u);
      if (u === end) break;
      links.filter(l => l.from === u || l.to === u).forEach(l => {
        const v = l.from === u ? l.to : l.from;
        if (!Q.has(v)) return;
        const alt = dist[u] + l.dist;
        if (alt < dist[v]) { dist[v] = alt; prev[v] = u; }
      });
    }
    let path = [], u = end;
    while (u) { path.unshift(u); u = prev[u]; }
    return path;
  };

  // --- Choix aléatoire de destination ---
  useEffect(() => {
    if (!mapData?.nodes?.length) return;
    const nodes = mapData.nodes;
    const startNode = nodes.reduce((prev, cur) =>
      new THREE.Vector3(cur.x, 0, cur.z).distanceTo(new THREE.Vector3(...position)) <
      new THREE.Vector3(prev.x, 0, prev.z).distanceTo(new THREE.Vector3(...position))
        ? cur : prev
    );
    const endNode = nodes[Math.floor(Math.random() * nodes.length)];
    const nodePath = findPath(startNode.id, endNode.id);
    const pointPath = nodePath.map(id => {
      const n = nodes.find(n => n.id === id);
      return new THREE.Vector3(n.x, 0, -n.z);
    });
    setPath(pointPath);
    setIdx(0);
  }, [mapData]);

  // --- Animation ---
  useEffect(() => {
    if (!animations?.length) return;
    const action = mixer.clipAction(animations[0]);
    action.setLoop(THREE.LoopRepeat, Infinity);
    action.play();
  }, [animations, mixer]);

  // --- Avance le long du chemin ---
  useEffect(() => {
    const tick = () => {
      const delta = clock.getDelta();
      mixer.update(delta);
      if (!group.current || path.length < 2) return;

      const pos = group.current.position;
      const target = path[idx + 1];
      if (!target) {
        // arrivé → nouveau trajet
        const endNode = mapData.nodes[Math.floor(Math.random() * mapData.nodes.length)];
        const nodePath = findPath(path[path.length - 1].id, endNode.id);
        const pointPath = nodePath.map(id => {
          const n = mapData.nodes.find(n => n.id === id);
          return new THREE.Vector3(n.x, 0, -n.z);
        });
        setPath(pointPath);
        setIdx(0);
        return;
      }

      const dir = target.clone().sub(pos).normalize();
      pos.addScaledVector(dir, speed);

      if (pos.distanceTo(target) < 0.2) setIdx(i => i + 1);

      // oriente vers direction
      group.current.rotation.y = Math.atan2(dir.x, dir.z);

      requestAnimationFrame(tick);
    };
    tick();
  }, [path]);

  return (
    <group ref={group} position={position}>
      <primitive object={cloned} scale={0.1} />
    </group>
  );
}

useGLTF.preload("/models/woman.glb");
